package com.exhibition.project.BoardDto;

public class ReportDto {
	private String userid;
	private String boardtitle;
	private String board_comment;
	private String report_comment;
	ReportDto(){
		
	}
	
	public ReportDto(String userid, String boardtitle, String board_comment, String report_comment) {
		super();
		this.userid = userid;
		this.boardtitle = boardtitle;
		this.board_comment = board_comment;
		this.report_comment = report_comment;
	}

	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getBoardtitle() {
		return boardtitle;
	}
	public void setBoardtitle(String boardtitle) {
		this.boardtitle = boardtitle;
	}
	public String getBoard_comment() {
		return board_comment;
	}
	public void setBoard_comment(String board_comment) {
		this.board_comment = board_comment;
	}
	public String getReport_comment() {
		return report_comment;
	}
	public void setReport_comment(String report_comment) {
		this.report_comment = report_comment;
	}
	

}
