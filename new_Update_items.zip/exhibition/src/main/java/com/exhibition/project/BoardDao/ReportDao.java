package com.exhibition.project.BoardDao;

public interface ReportDao {
	//report//
		public void try_report(String userid, String boardTitle, String board_comment,String report_comment);
}
