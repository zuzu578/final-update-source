package com.exhibition.project.BoardDto;

public class MemberDto {
	private int member_num;
	private String id;
	private String email;
	private String paswd;
	private String gender;
	private String mobile;
	private String address;
	private String name;
	MemberDto(){
		
	}
	
	public MemberDto(int member_num, String id, String email, String paswd, String gender, String mobile,
			String address, String name) {
		super();
		this.member_num = member_num;
		this.id = id;
		this.email = email;
		this.paswd = paswd;
		this.gender = gender;
		this.mobile = mobile;
		this.address = address;
		this.name = name;
	}

	public int getMember_num() {
		return member_num;
	}
	public void setMember_num(int member_num) {
		this.member_num = member_num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPaswd() {
		return paswd;
	}
	public void setPaswd(String paswd) {
		this.paswd = paswd;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
