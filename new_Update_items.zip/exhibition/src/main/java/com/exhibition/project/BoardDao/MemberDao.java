package com.exhibition.project.BoardDao;

import java.util.ArrayList;

import com.exhibition.project.BoardDto.BoardDto;
import com.exhibition.project.BoardDto.MemberDto;

public interface MemberDao {

	MemberDto userinfoSelect(String Userid);

	void UserUpdate(String member_num,String id, String email, String paswd, String gender, String mobile, String address, String name,
			String f);

	void NofileWrite(String member_num, String id, String email, String paswd, String gender, String mobile,
			String address, String name);

	String ProfileImage(String Rankingid);

	String SecondProfileImage(String secDto);

}
